# Active Learning Designer

## How to use

Upload or install the skill folder, including `SKILL.md` and `references/`. Ask for an active-learning exercise for a topic or your course materials. Review and revise the exercise conversationally. When satisfied, say **“Generate the Classroom Delivery Package for this activity.”**

The package can contain PowerPoint slides, a facilitator guide and, when pedagogically useful and supported by the environment, a self-contained interactive HTML tool. The activity can be used without generating those files.

**Test request:** “Use Active Learning Designer to produce a Classroom Delivery Package for our Theory of Constraints Bottleneck Challenge, including an offline interactive capacity simulator. Keep the latest agreed scenario and the facilitator-only answer key separate from student slides.”

File generation depends on the capabilities available in your AI environment.
