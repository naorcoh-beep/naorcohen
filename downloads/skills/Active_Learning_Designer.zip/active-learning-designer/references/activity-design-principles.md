# Activity design principles (internal reference)

Use these as decision lenses, not universal mandates. Do not cite studies that have not been accessed or verified.

## Match activity to cognitive demand

- Retrieval/fluency: short individual recall followed by corrective feedback; not every concept needs a game.
- Conceptual differentiation: contrasting cases, concept mapping, error diagnosis, classification with justification.
- Application and transfer: new situations with decision constraints, competing interpretations, counterexamples, and revision.
- Judgement and ethical reasoning: dilemmas with defensible alternatives, stakeholder implications, and explicit decision criteria.
- Skill rehearsal: staged practice, role-play, simulation, observation criteria, feedback, and a second attempt.
- Integration/synthesis: cumulative problem, compare-and-reconcile, teach-back, or evidence-based recommendation.

## Common activity structures and failure modes

- **Think-pair-share:** protects individual processing, but vague prompts yield superficial talk. Require a specific claim and reason.
- **Peer instruction:** ask a diagnostic conceptual question, get independent commitment, peer discussion, re-vote and explanation. Requires plausible distractors and a useful reveal.
- **Case decision:** present incomplete but sufficient information, require a choice and defence, then complicate or reveal additional information. Debrief evidence and trade-offs.
- **Debate:** best for bounded, genuinely contestable claims with clear criteria. Do not mistake rhetorical performance for understanding.
- **Role-play/simulation:** define roles, constraints, information asymmetry if relevant, interaction rules, time and post-activity analysis. Always provide de-roling/reflection when emotional issues arise.
- **Group problem-solving:** ensure task interdependence and individual accountability. Assigning four isolated subquestions to four people is task division, not collaboration.
- **Reflection:** prompt specific comparison, evidence, or a revised model; avoid empty 'how did you feel?' questions.

## Facilitation and workload

- Write instructions students can understand without oral improvisation.
- Allocate time for instructions, setup, individual thought, action, reporting, debrief and checking learning. Time budgets must add up.
- Plan for early finishers, disagreement, silence, dominant voices, and groups that cannot reach consensus.
- Use formative outputs when they suffice; don't turn every activity into a graded assignment.
- For large enrolments, use pairs, short written commitments, polling, targeted sampling, and selective reporting rather than every group presenting.
- In asynchronous settings, replace rapid live interaction with explicit phases, deadlines, revision opportunities and accessible participation options.
- Respect accessibility and reasonable alternative ways to contribute; avoid requiring self-disclosure or putting students into identity-based roles.

## Debrief is part of the learning

Ask: What did you decide or observe? What evidence and assumptions guided you? How would the concept explain it? What alternative interpretation exists? When would this strategy fail? What would you do differently next time? End with a crisp conceptual synthesis and a learning check.

## Appropriate use of AI

Distinguish productive AI-supported evaluation from surrendering the intended cognitive work. For activities involving AI output, consider individual prediction before seeing it, contrast between outputs, explicit error hunting, evidence tracing, and student-authored final decisions.
