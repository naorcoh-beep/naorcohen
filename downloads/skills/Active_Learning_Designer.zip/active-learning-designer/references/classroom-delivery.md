# Classroom Delivery Package: production guidance

## Purpose and trigger

This is an optional *production* phase, not a new activity-design stage. Offer it once at the end of the first complete activity, in one sentence. Continue to refine the activity freely. Generate only on explicit instructor request; do not require a ceremonial approval step. If multiple revisions occurred, treat the latest accepted content as authoritative.

## Package contents

1. **Classroom slides (`.pptx`)**: a concise widescreen teaching deck, preferably 5–9 slides for a short exercise, adjusted to the actual activity. Include: title and outcome; scenario/data; exact student instructions; stage timings; decision/questions; reveal or complication; results/discussion; debrief and learning check. Use legible typography, clear graphs, accessible colour contrast, restrained styling, and no filler. Include speaker notes when the production tools support them. Answers intended for later reveal must not appear prematurely in projected content.
2. **Facilitator guide (`.md` or `.pdf`)**: stage-by-stage timing and cues, setup requirements, authoritative calculations and model responses (clearly labelled as examples), anticipated misconceptions, probing questions, contingencies, a substantive debrief, and an individual learning check. Standalone enough to teach without revisiting the original conversation.
3. **Interactive companion (`.html`)**, *only if it materially helps the intended thinking*: a single self-contained offline page with inputs/sliders, labelled outputs and units, reset and default values, accessible keyboard-friendly controls, a concise assumption statement, and if useful a prediction-before-reveal prompt. Prefer small transparent models over decorative widgets. Do not add one simply because a quantitative topic exists. Include a clickable relative link from the slides when possible and a human-readable filename as fallback; the HTML must ship in the same package folder so that the relative link works. Standard PowerPoint cannot be assumed to run arbitrary live HTML internally.

## Delivery format and implementation

When supported, create individual downloadable files and a ZIP containing all outputs plus a short README with usage instructions. Do not promise a PPTX/HTML unless files can actually be created. Use available artifact tools or code in the current runtime; do not assume a special slide-generation plugin is installed. If necessary and possible, create the presentation using available libraries. Check that files exist before providing download links. Do not require external APIs or cloud services for the companion. If the environment cannot make files, supply ready-to-copy slide content and an explicitly labelled code alternative.

## Consistency contract

- Preserve exact scenario, quantities, formulas, assumptions, timing, and latest user edits. If source figures are internally inconsistent, flag and repair them transparently instead of embedding a broken model.
- Differentiate capacity, throughput, WIP, rates, profit, contribution, and other units carefully. Show assumptions such as deterministic flow and initial inventory.
- Separate student-facing and confidential instructor materials. Use staged reveals or notes where needed.
- For simulations, validate default outputs against the instructor key and test parameter extremes, non-binding constraints, ties, and reset. Avoid implied causal precision beyond the model.
- The package is not a substitute for pedagogical judgement. Maintain substantive debrief and learning evidence, not merely attractive slides.

## Minimal invitation to appear after an initial activity

> Once you're happy with the activity, I can generate a **Classroom Delivery Package** with PowerPoint slides, facilitator notes, and an interactive simulation or calculator when useful. You can revise the activity first.

Offer this once per completed activity. When the user asks for a package, generate it directly rather than asking them to copy a prompt.
