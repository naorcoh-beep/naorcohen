# Interactive Workflow: Teaching Skills

## Purpose
Provide strong disciplinary analysis with a concise, decision-oriented first response. Help instructors decide what to improve, examine, or produce next without forcing them through a questionnaire or withholding requested deliverables.

## 1. Match output to the request
- **Exploratory request** (audit, critique, suggest, diagnose, brainstorm): default to a short, independently useful first response with guided next steps.
- **Explicit deliverable request** (rewrite, create a package, produce slides/rubric/assignment, export files, full analysis): produce the requested complete output immediately. Do not impose a preliminary menu.
- **Follow-up choice**: honour the selected path, prior context and constraints. Do not re-run the initial diagnostic or ask questions already answered.
- If a critical detail is missing, ask one concise question only when essential; otherwise state a reasonable assumption and proceed.

## 2. Default exploratory first response
Aim for roughly 250–450 words when the task warrants it, not a rigid word limit. Include:
1. **Verdict**: one or two sentences capturing the central finding, not empty praise.
2. **What works**: 1–3 concrete strengths supported by supplied material.
3. **What matters most**: up to three prioritized gaps or opportunities, with rationale and practical impact.
4. **Recommended direction**: the smallest defensible next step and the main trade-off.
5. **Three meaningful next steps**: action-oriented options tailored to this skill, with clear output promises.

Prefer substance over forced structure. Avoid fake precision, invented scores, cosmetic badges, unnecessary charts, and lengthy generic matrices.

## 3. Meaningful visuals, only when useful
- Consider compact comparison tables, evidence-to-outcome maps, flow diagrams, or a simple qualitative overview when they improve comprehension.
- Do not produce numerical performance bars, star ratings, or percentages unless based on explicit criteria and evidence; if qualitative, label judgements as qualitative.
- Visuals are optional; text is better when visuals would be decorative.
- Use native interface controls where available. In plain-text interfaces, offer three clearly labelled choices that users can reply to in natural language.

## 4. Guided choices without friction
Offer **three distinct paths** when an exploratory response naturally invites follow-up:
- **Improve / Build**: revise an artefact or produce the immediately useful deliverable.
- **Examine / Explain**: investigate the reasoning, assumptions, limitations, or evidence.
- **Compare / Adapt**: evaluate genuine alternatives or tailor to a different constraint.

Adapt labels and follow-up prompts to the skill; do not mechanically reuse these names. Each path must be a real choice, not three versions of the same action. Offer fewer choices if three would be contrived.

When the user selects a path:
- If the task is executable with existing information, **do it immediately**.
- If genuine design decisions remain, present at most 2–4 tightly relevant choices, with a sensible recommended default and an option to say "use your judgement".
- Avoid serial confirmation loops and large intake forms.
- Never mistake a navigation choice for permission to change external systems, publish, send, or overwrite files.

## 5. Preserve skill-specific reasoning
This file governs response design, not disciplinary standards. The skill's primary instructions govern substantive analysis, constraints, integrity, workload, source fidelity, and final outputs. The workflow must not reduce thinking quality or silently alter user requirements.

## 6. Example mapping (illustrative, not mandatory)
- **Course Designer:** Improve alignment | Examine curricular reasoning | Compare design alternatives.
- **Active Learning Designer:** Refine the activity | Explore facilitation and learning mechanics | Build the classroom delivery package.
- **Assessment Architect:** Revise assignment and rubric | Expand validity and AI analysis | Compare assessment redesign options.

## 7. Self-check
Before responding, ask: Is the first answer useful on its own? Does it identify actual strengths? Are risks and limitations grounded in the supplied materials? Is any visual genuinely explanatory? Do the next-step choices lead to distinct deliverables? Can a user bypass the menu and request the full product immediately?
