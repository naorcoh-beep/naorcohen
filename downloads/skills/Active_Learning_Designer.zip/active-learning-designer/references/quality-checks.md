# Active Learning Designer quality gate

Apply silently before finalising the output. Repair failures rather than merely attaching a checklist.

1. **Purpose:** Is the learning aim a performance, rather than 'engage students' or 'have a discussion'?
2. **Student thinking:** Will students explain, judge, practise, discriminate, retrieve, or revise, rather than simply restate information?
3. **Specificity:** Are the scenario, prompts, exact instructions and student output supplied or explicitly tied to actual source materials?
4. **Timing and instructor control:** Does the activity honour any specified duration or range? When duration is unspecified, is the proposed timing clearly recommended and adjustable rather than a fixed default? Are setup, transitions, work and debrief included, with minutes adding up exactly? If time is insufficient, is the trade-off explicit?
5. **Feasibility:** Does group structure work for the enrolment, classroom and preparation constraints? Is instructor workload reasonable?
6. **Inclusion:** Are participation expectations clear and reasonable without avoidable barriers or personal disclosures?
7. **Facilitation:** Are likely student responses, misconceptions, probing questions and contingencies available?
8. **Debrief:** Does it connect experience to disciplinary ideas, decisions, evidence and transfer?
9. **Evidence:** Is there a proportionate check of understanding beyond satisfaction or participation?
10. **Integrity:** Are hypothetical facts labelled, actual sources faithfully represented, and student/instructor materials distinct?
11. **AI judgement:** If AI is relevant, does its assigned role protect the target student thinking and respect local policy?
12. **Restraint:** Is this the simplest adequate design, without unnecessary complexity, gimmicks, or a stack of alternative activities?

13. **Delivery-package consistency:** If files are requested, do slides, instructor notes, and interactive defaults match the latest agreed activity and timing?
14. **Separation and reveal:** Are confidential answers and role details absent from student-facing materials prior to reveal?
15. **Interactive validity:** Have boundary cases, numerical inputs, output units, reset, and offline use been tested when applicable?
16. **File honesty:** Are downloads actual files verified in the active environment, with no assumed export capability?
