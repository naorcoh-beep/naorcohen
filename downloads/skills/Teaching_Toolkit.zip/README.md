# Teaching Toolkit

Three connected skills that also work independently:

- Course Designer: clarify course learning goals and align the course design.
- Active Learning Designer: develop and refine runnable learning activities.
- Assessment Architect: design and review assessments and marking guidance.

## Install one skill or use all three

Each named folder is a complete independent skill. Keep its SKILL.md and references folder together. Use your AI assistant's supported skill-installation flow for the folder. If it only accepts an individual skill ZIP, use the corresponding individual download from the website rather than installing this multi-skill archive as one skill.

If no installer is available but file uploads are supported, attach the chosen skill's SKILL.md and reference files to a conversation and ask the assistant to use them. This supplies instructions for that conversation; it does not install a permanent skill. Capabilities vary by environment.

Share only teaching materials you are permitted to use and remove personal or confidential information. Review generated suggestions against your disciplinary context and local requirements.

The shared interactive workflow is included in every skill so each remains complete on its own. Exploratory requests receive useful concise guidance and meaningful next steps. You can request complete deliverables immediately without going through a menu.

The skills retain their supplied licence metadata. Examples, classroom demonstration packages and private project materials are not included.
