# Assessment design principles and decisions

Use as practical reasoning aids, not as a rigid checklist or claim of universal pedagogical evidence.

## Validity: evidence supports an interpretation

Ask what inference an instructor wants to draw about the learner, and whether the requested task actually supports it. An elegant essay may show synthesis under resource-rich conditions but not unaided recall. An invigilated quiz may reveal recall and time-limited application but not necessarily professional judgement in a complex setting. Different evidence supports different conclusions.

Two common threats:

- **Construct underrepresentation:** The task covers only a narrow slice of what matters (for example, vocabulary questions for a course seeking ethical judgement).
- **Construct-irrelevant variation:** Scores reflect resources, language complexity, task familiarity, presentation polish, technology, speed or support that are not part of the intended learning outcome.

Never claim that one format guarantees validity. Consider combinations of evidence only when the additional component has clear value.

## Authenticity, difficulty and fairness

Authentic tasks resemble meaningful disciplinary work, but authenticity is not synonymous with complexity. Supply enough context and data for fair evaluation. Avoid needless role-playing, jargon, costly platforms or personal disclosure. An authentic decision task should require choice among plausible alternatives with genuine consequences, not a hidden 'obvious' right answer.

Separate the *difficulty of reasoning* from the difficulty of figuring out instructions. For accessibility, provide alternative means of demonstrating equivalent learning where feasible, consistent with local policy.

## Assessment for learning versus assessment of learning

Formative checks are valuable when students can use feedback to improve. Summative assessments aim to support defensible achievement decisions. One task can serve both purposes, but describe the feedback timing and actual opportunities to respond. Do not prescribe endless cycles of drafts or expensive individualized feedback.

## Rubric choice

- **Analytic:** Useful for multiple distinct dimensions and detailed feedback; can increase marking burden and false precision.
- **Holistic:** Useful when overall quality and expert judgement matter; provide anchor descriptions and moderation for consistency.
- **Checklist/threshold:** Useful for foundational requirements or mastery standards; distinguish completion from quality.
- **Specifications/bundles:** A common high threshold can apply to shared core tasks across pathways, while higher grades may require *additional work*, not lower standards on identical work. Make bundles, attempts and consequences explicit.

Use calibrated examples where possible. Weight only meaningful dimensions. Avoid excessive criteria, pseudo-quantification and overlapping categories. Ensure high and low levels describe differences in quality of reasoning or execution, not merely 'excellent' versus 'poor'.

## AI-use decision framework

1. Determine the target capability: independent, AI-assisted, evaluative, or mixed.
2. Choose permissible tools and explicit constraints; do not invent policy.
3. Design task evidence suited to that target; a polished final submission alone rarely shows how it was produced.
4. Specify what students must disclose when appropriate and why.
5. Verify that extra checkpoints provide enough educational benefit to justify instructor and student burden.

Illustrations:

- **Independent judgement:** supervised unfamiliar mini-case with concise justification.
- **AI-assisted professional output:** use AI to draft a recommendation, then substantiate claims, expose weaknesses and defend a revised recommendation against evidence.
- **Comparative evaluation:** evaluate two conflicting solutions with criteria, identify unsupported assumptions and make a reasoned selection.
- **Learning process:** brief staged reasoning and revision when the process itself is an intended outcome.

An oral defence, version history, or reflection can add evidence but does not reliably establish authorship in isolation. Detection tools are not adequate substitutes for academic due process.

## Feasibility and calibration

Estimate grading time, feedback detail, class size, number of artefacts, accommodation needs and potential appeals. Reduce grading cost with short but meaningful submissions, sampled feedback, clearly chosen dimensions, common-error feedback, exemplars or calibrated marking. Do not recommend automated final grades without authorized oversight.

## Critiquing a task

Identify (1) what is currently working, (2) the most consequential mismatch between intended learning and observable evidence, (3) how a student might succeed without mastering the target, (4) a minimal fix, and (5) the trade-off. Avoid 'AI-proofing' as a goal detached from learning.
