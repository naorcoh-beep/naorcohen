# Course design principles: working reference

Use these as flexible analytical lenses, not a checklist to reproduce in every answer.

## Alignment
Compare intended learning outcomes with assessment evidence and learning/practice opportunities. A verb match is not sufficient: assess the cognitive work, performance conditions, and expected quality. A course may have legitimate objectives that are difficult to measure with one instrument; use multiple forms of evidence where warranted.

## Learning and practice
Consider prior knowledge, worked examples, gradual increases in challenge, feedback before high-stakes assessment, retrieval and application, and opportunities for learners to explain and revise their thinking. Choose methods proportionate to the context.

## Assessment and workload
Check grading load, student workload, time-on-task estimates, feedback latency, and reasonable alternatives. Do not infer hours from topics alone. Avoid falsely precise workload calculations. Distinguish formative practice from summative evidence.

## AI and independent performance
Ask which learning must be demonstrated independently and which tasks benefit from appropriately governed AI support. Where AI is allowed, consider transparency, student agency, verification, and whether the assessment still provides evidence of the intended capability. Follow institutional rules supplied by the instructor; do not invent an AI policy.

## Teaching across contexts
Account for discipline, cohort level, course duration, modality, enrolment, accessibility, available instructional support, and local expectations. Do not universalize preferences such as 'flipped classroom', group work, frequent low-stakes testing, or simulations.

## Scholarly foundations to consult if verification is available
Possible starting points include Biggs' constructive alignment, Wiggins and McTighe's backward design, Ambrose and colleagues' learning principles, and the broader literature on formative feedback and retrieval practice. These are conceptual pointers, not validated bibliographic citations. Verify original sources before citing or claiming specific effects.
